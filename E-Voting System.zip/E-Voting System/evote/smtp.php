<?php
include "classes/class.phpmailer.php"; // include the class name
$hostname_localhost ="localhost";
$database_localhost ="votingsystem";
$username_localhost ="root";
$password_localhost ="";
$localhost = mysql_connect($hostname_localhost,$username_localhost,$password_localhost)
or
trigger_error(mysql_error(),E_USER_ERROR);

mysql_select_db($database_localhost, $localhost);
$voterid = $_POST['names'];
$otp=$_POST['otp'];
$mail = new PHPMailer(); // create a new object
$mail->IsSMTP(); // enable SMTP
$mail->SMTPDebug = 1; // debugging: 1 = errors and messages, 2 = messages only
$mail->SMTPAuth = true; // authentication enabled
$mail->SMTPSecure = 'ssl'; // secure transfer enabled REQUIRED for GMail
$mail->Host = "smtp.gmail.com";
$mail->Port = 465; // or 587
$mail->IsHTML(true);
$mail->Username = "abc@gmail.com"; //enter sender emailid
$mail->Password = "*****"; //enter password
$mail->SetFrom("abc@gmail.com"); //enter sender email id
$mail->Subject = "E-Voting System";
$mail->Body = "<b>Welcome to E-Voting System. Your OTP password is ".$otp."</b>";

$query_search = "select email_id from voterlist where voterid = '". $voterid. "'";
$query_exec = mysql_query($query_search) or die(mysql_error());
$rows = mysql_num_rows($query_exec);
$retval = mysql_query($query_search,$localhost );
//echo $rows;
 if($rows == 0) { 
 echo "Email Id Not Found."; 
 }
 else  {
if($row = mysql_fetch_array($retval, MYSQL_ASSOC))
{
	
	$mailId=$row['email_id'];
$mail->AddAddress($mailId);
 if(!$mail->Send()){
	echo "Mailer Error: " . $mail->ErrorInfo;
}
else{
	
	echo "Mail sent successfully";
	
}
}
 }
?>