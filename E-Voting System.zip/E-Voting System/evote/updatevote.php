<?php
$hostname_localhost ="localhost";
$database_localhost ="votingsystem";
$username_localhost ="root";
$password_localhost ="";
$localhost = mysql_connect($hostname_localhost,$username_localhost,$password_localhost)
or
trigger_error(mysql_error(),E_USER_ERROR);

mysql_select_db($database_localhost, $localhost);
//$id = $_POST['candidatename'];
//$voterid=$_POST['voterid'];
$id = $_POST['candidatename'];
$voterid=$_POST['voterid'];
$query_search = "select votes from candidatelist where fullname = '". $id. "'";
$query_exec = mysql_query($query_search) or die(mysql_error());
$rows = mysql_num_rows($query_exec);
$retval = mysql_query($query_search,$localhost );
//echo $rows;
 if($rows == 0) { 
 echo "Not Found"; 
 }
 else  {
if($row = mysql_fetch_array($retval, MYSQL_ASSOC))
{
	$cvote= $row['votes'];  
	
      $count=$cvote+1;
$sql = "UPDATE `candidatelist` SET `votes`=".$count." WHERE fullname='".$id. "'" ;

$retval = mysql_query( $sql, $localhost );
if(! $retval )
{
  die('Could not update data: ' . mysql_error());
}
$sql = 'INSERT INTO `votes`( `voterid`) VALUES ('.$voterid.')';
  
   $retval1 = mysql_query( $sql, $localhost );
   
   if(! $retval1 )
   {
      die('Could not enter data: ' . mysql_error());
   }
  
echo "Vote submitted successfully\n";    	
}
 
}

?>