<?php
$host="localhost"; //replace with database hostname 
$username="root"; //replace with database username 
$password=""; //replace with database password 
$db_name="votingsystem"; //replace with database name
 
$con=mysql_connect("$host", "$username", "$password")or die("cannot connect"); 
mysql_select_db("$db_name")or die("cannot select DB");
$voterid=$_POST['voterid'];

$sql = "SELECT `votetime` FROM `votes` WHERE `voterid`='".$voterid."'"; 
$result = mysql_query($sql);
if(mysql_num_rows($result)){
while($row=mysql_fetch_assoc($result)){
$votetime=$row['votetime'];
echo $votetime;
}
}
mysql_close($con);

?>