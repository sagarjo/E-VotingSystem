<?php
$hostname_localhost ="localhost";
$database_localhost ="votingsystem";
$username_localhost ="root";
$password_localhost ="";
$localhost = mysql_connect($hostname_localhost,$username_localhost,$password_localhost)
or
trigger_error(mysql_error(),E_USER_ERROR);

mysql_select_db($database_localhost, $localhost);
$vote=$_POST['name'];

$query_search= "select * from voterlist WHERE voterid='".$vote ."'";
$query_exec = mysql_query($query_search) or die(mysql_error());
$rows = mysql_num_rows($query_exec);
$retval = mysql_query($query_search,$localhost );
//echo $rows;
 if($rows == 0) { 
 echo "Invalid Voter"; 
 }
 else  {
	while($row = mysql_fetch_array($retval, MYSQL_ASSOC))
{
$query_search1= "select * from votes WHERE voterid='".$vote ."'";
$query_exec = mysql_query($query_search1) or die(mysql_error());
$rows1 = mysql_num_rows($query_exec);
$retval1 = mysql_query($query_search1,$localhost );
//echo $rows;
 if($rows1 == 0) { 
 echo "Not Voted"; 
 }
 else  {
	while($row = mysql_fetch_array($retval1, MYSQL_ASSOC))
{
	echo "Already Voted";
}
}
}
 }
?>