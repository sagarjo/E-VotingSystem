<?php
$host="localhost"; //replace with database hostname 
$username="root"; //replace with database username 
$password=""; //replace with database password 
$db_name="votingsystem"; //replace with database name
 
$con=mysql_connect("$host", "$username", "$password")or die("cannot connect"); 
mysql_select_db("$db_name")or die("cannot select DB");

$voterid=$_POST['voterid'];

$sql = "select ward from voterlist where voterid='".$voterid."'"; 
$result = mysql_query($sql);
if(mysql_num_rows($result)){
while($row=mysql_fetch_assoc($result)){
$ward=$row['ward'];
}
}
$sql = "select * from candidatelist where ward='$ward'"; 
$result = mysql_query($sql);
$json = array();
 
if(mysql_num_rows($result)){
while($row=mysql_fetch_assoc($result)){
$json['candidates'][]=$row;
}
}
mysql_close($con);
echo json_encode($json);

?>