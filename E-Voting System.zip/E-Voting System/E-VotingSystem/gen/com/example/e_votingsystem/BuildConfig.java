/** Automatically generated file. DO NOT MODIFY */
package com.example.e_votingsystem;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}