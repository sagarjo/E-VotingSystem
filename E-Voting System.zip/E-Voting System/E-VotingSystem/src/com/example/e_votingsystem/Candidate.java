package com.example.e_votingsystem;

public class Candidate {
	private String candidatename;

	public String getCandidatename() {
		return candidatename;
	}

	public void setCandidatename(String candidatename) {
		this.candidatename = candidatename;
	}

	public Candidate(String candidatename) {
		super();
		this.candidatename = candidatename;
	}

}
