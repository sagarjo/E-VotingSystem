package com.example.e_votingsystem;

import java.io.*;
import java.util.*;

import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.BasicResponseHandler;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.json.*;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;

import android.os.AsyncTask;
import android.os.Bundle;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.widget.*;

import android.widget.AdapterView.OnItemClickListener;
public class CandidateActivity extends Activity {
	String voterid="";
	 String myipaddress="";
	 HttpPost httppost;
		StringBuffer buffer;
		HttpResponse response;
		HttpClient httpclient;
		List<NameValuePair> nameValuePairs;
	  	JSONParser jParser = new JSONParser();
	  	private String jsonResult;
	  	 private ListView listView;
	  	 JSONParser jsonParser = new JSONParser();
		 Bundle b;
		 List<Map<String, String>> employeeList = new ArrayList<Map<String, String>>();
		 
		 int vote=0;
		 String response1="";
		 ProgressDialog dialog = null;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_candidate);
		Bundle bundle = getIntent().getExtras();
		
		 voterid = bundle.getString("VoterId");
		 myipaddress = bundle.getString("IP");
		Toast.makeText(getApplication(), voterid+", "+myipaddress, Toast.LENGTH_LONG).show();
		listView = (ListView) findViewById(R.id.listview1);
		 	
		  accessWebService();
		  initList();
		  
	}
	
	
	private void initList(){
		listView.setOnItemClickListener(new OnItemClickListener() {
			 
			@Override
			public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,
					long arg3) {

				// TODO Auto-generated method stub
				 Toast.makeText(getApplicationContext(),employeeList.get(arg2).toString(), Toast.LENGTH_LONG).show();
				 vote=arg2+1;
				 String a=employeeList.get(arg2).toString();
				 String name[]=a.split("-");
				 final String candidatename=name[1].replace("}", "");
				 System.out.println(name[1].replace("}", ""));
				 try{
					 dialog = ProgressDialog.show(CandidateActivity.this, "",
								"Updating voting Count", true);
						new Thread(new Runnable() {
							public void run() {
								try {
   
									httpclient = new DefaultHttpClient();
									httppost = new HttpPost(
											"http://"+myipaddress+":80/evote/updatevote.php"); // make
																										// sure
																										// the
																										// url
																										// is
																										// correct.
									// add your data
									nameValuePairs = new ArrayList<NameValuePair>(2);
									// Always use the same variable name for posting i.e the android
									// side variable name and php side variable name should be similar,
									nameValuePairs.add(new BasicNameValuePair("candidatename",candidatename.toString().trim())); 
									nameValuePairs.add(new BasicNameValuePair("voterid",voterid.toString().trim())); 
									
									System.out.println("a"+String.valueOf(vote));
									httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
									// Execute HTTP Post Request
									 Log.d("A", httppost.toString());
									ResponseHandler<String> responseHandler = new BasicResponseHandler();
									 response1 = httpclient.execute(httppost,
											responseHandler);
									System.out.println("Response : " + response);
									
									/*Starting a thread and getting and displaying balance */
									runOnUiThread(new Runnable() {
										public void run() {
											Toast.makeText(CandidateActivity.this, response1,Toast.LENGTH_LONG).show();
											dialog.dismiss();
											Intent intent=new Intent(CandidateActivity.this,MainActivity.class);
											startActivity(intent);
										}
									});
									
									

								} catch (Exception e) {
									
									System.out.println("Exception : " + e.getMessage());
								}	
							}
						}).start();
				 }catch(Exception e)
				 {
					 
				 }
			}
			}); 
	}
	

	private class JsonReadTask extends AsyncTask<String, Void, String> {
		  @Override
		  protected String doInBackground(String... params) {
			  
		   HttpClient httpclient = new DefaultHttpClient();
		   HttpPost httppost = new HttpPost(params[0]);
		   try {
		    HttpResponse response = httpclient.execute(httppost);
		    jsonResult = inputStreamToString(
		      response.getEntity().getContent()).toString();
		   }
		 
		   catch (ClientProtocolException e) {
		    e.printStackTrace();
		   } catch (IOException e) {
		    e.printStackTrace();
		   }
		   return null;
		  }
		 
		  private StringBuilder inputStreamToString(InputStream is) {
		   String rLine = "";
		   StringBuilder answer = new StringBuilder();
		   BufferedReader rd = new BufferedReader(new InputStreamReader(is));
		 
		   try {
		    while ((rLine = rd.readLine()) != null) {
		     answer.append(rLine);
		    }
		   }
		 
		   catch (IOException e) {
		    // e.printStackTrace();
		    Toast.makeText(getApplicationContext(),
		      "Error..." + e.toString(), Toast.LENGTH_LONG).show();
		   }
		   return answer;
		  }
		 
		  @Override
		  protected void onPostExecute(String result) {
		   ListDrwaer();
		  }
		 }// end async task
		 
		 public void accessWebService() {
			 String url = "http://"+myipaddress+":80/evote/candy.php?voterid="+voterid.toString().trim();
			 
		  JsonReadTask task = new JsonReadTask();
		  // passes values for the urls string array
		  task.execute(new String[] { url });
		 }
		 
		 // build hash set for list view
		 public void ListDrwaer() {
		 
		  try {
		   JSONObject jsonResponse = new JSONObject(jsonResult);
		   JSONArray jsonMainNode = jsonResponse.optJSONArray("candidate_info");
		 
		   for (int i = 0; i < jsonMainNode.length(); i++) {
		    JSONObject jsonChildNode = jsonMainNode.getJSONObject(i);
		    String name = jsonChildNode.getString("id");
		    String number = jsonChildNode.getString("fullname");
		    String outPut = name + "-" + number;
		    employeeList.add(createEmployee("candidates", outPut));
		   }
		  } catch (JSONException e) {
		   Toast.makeText(getApplicationContext(), "Error" + e.toString(),
		     Toast.LENGTH_SHORT).show();
		  }
		 
		  SimpleAdapter simpleAdapter = new SimpleAdapter(this, employeeList,
		    android.R.layout.simple_list_item_1,
		    new String[] { "candidates" }, new int[] { android.R.id.text1 });
		  listView.setAdapter(simpleAdapter);
		 }
		 
		 private HashMap<String, String> createEmployee(String name, String number) {
		  HashMap<String, String> employeeNameNo = new HashMap<String, String>();
		  employeeNameNo.put(name, number);
		  return employeeNameNo;
		 }	
              
		

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.candidate, menu);
		return true;
	}
	

}
