package com.example.e_votingsystem;

import java.util.ArrayList;
import java.util.List;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.BasicResponseHandler;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import android.os.Bundle;
import android.app.AlertDialog;
import android.app.ListActivity;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.DialogInterface.OnClickListener;
import android.util.Log;
import android.view.KeyEvent;
import android.widget.TextView;
import android.widget.Toast;

public class NotificationActivity extends ListActivity {
	NotificationActivity aa=null;
String voterid="";
String myipaddress="";
HttpPost httppost;
StringBuffer buffer;
HttpResponse response;
HttpClient httpclient;
TextView ward;
List<NameValuePair> nameValuePairs;
String response1="";
	JSONParser jParser = new JSONParser();
	ProgressDialog dialog = null;
	JSONArray array;
	private ArrayList<Notify> m_parts = new ArrayList<Notify>();
	private Runnable viewParts;
	private NotifyAdapter m_adapter;
	TextView t1;
	String time="";
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_notification);
		Bundle bundle = getIntent().getExtras();
		 voterid = bundle.getString("VoterId");
		 myipaddress = bundle.getString("IP");
		Toast.makeText(getApplication(), voterid+", "+myipaddress, Toast.LENGTH_LONG).show();
		aa=this;
		t1=(TextView)findViewById(R.id.votetime);
		ward=(TextView)findViewById(R.id.ward);
		
		 m_adapter = new NotifyAdapter(this, R.layout.notify, m_parts);
	        setListAdapter(m_adapter);
	       
	     // here we are defining our runnable thread.
	        viewParts = new Runnable(){
	        	public void run(){
	        		try {
						
					httpclient = new DefaultHttpClient();
					httppost = new HttpPost("http://"+myipaddress+":80/evote/votetime.php"); 
					// add your data
					
					nameValuePairs = new ArrayList<NameValuePair>(2);
					
					// Always use the same variable name for posting i.e the android
					// side variable name and php side variable name should be similar,
						nameValuePairs.add(new BasicNameValuePair("voterid",voterid.toString().trim())); 
						
					httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
					// Execute HTTP Post Request
					 Log.d("B", httppost.toString());
					
					ResponseHandler<String> responseHandler = new BasicResponseHandler();
					 time = httpclient.execute(httppost,responseHandler);
					System.out.println("Responses : " + time);
					runOnUiThread(new Runnable() {
						public void run() {
					t1.setText(time.toString().trim());
						}
					});
				}catch(Exception e){
					System.out.println(e);
				}
	        		getnotification();
	        		
	        	}
	        };

	        // here we call the thread we just defined - it is sent to the handler below.
	        Thread thread =  new Thread(null, viewParts, "MagentoBackground");
	        thread.start();
		
	}

	
	protected void votetime() {
		// TODO Auto-generated method stub
		
	}


	protected void getnotification() {

		new Thread(new Runnable() {
			public void run() {
				try {

					httpclient = new DefaultHttpClient();
					httppost = new HttpPost(
							"http://"+myipaddress+":80/evote/votes.php"); // make
																						// sure
																						// the
																						// url
																						// is
																						// correct.
					// add your data
					nameValuePairs = new ArrayList<NameValuePair>(2);
					// Always use the same variable name for posting i.e the android
					// side variable name and php side variable name should be similar,
						nameValuePairs.add(new BasicNameValuePair("voterid",voterid.toString().trim())); 
					
				
					httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
					// Execute HTTP Post Request
					 Log.d("A", httppost.toString());
					ResponseHandler<String> responseHandler = new BasicResponseHandler();
					 response1 = httpclient.execute(httppost,
							responseHandler);
					System.out.println("Response : " + response1);
					JSONObject json = new JSONObject(response1);
					 array = json.getJSONArray("candidates");
					runOnUiThread(new Runnable() {
						public void run() {
							 try {
							ward.setText("Ward : "+array.getJSONObject(0).getString("ward"));
					for(int i = 0 ; i < array.length() ; i++){
						
					 
						System.out.println(array.getJSONObject(i).getString("ward"));
						m_parts.add(new Notify(array.getJSONObject(i).getString("fullname"),array.getJSONObject(i).getString("votes")));
						m_adapter = new NotifyAdapter(NotificationActivity.this, R.layout.notify,m_parts);

						// display the list.
				        setListAdapter(m_adapter);
					}
					  } catch (JSONException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					 

					}
					
						}
					});
					
				
				} catch (Exception e) {
					
					System.out.println("Exception : " + e.getMessage());
				}	
			}
		}).start();
	}
	 @SuppressWarnings("deprecation")
		public boolean onKeyDown(int keyCode, KeyEvent event)  {
		        if (keyCode == KeyEvent.KEYCODE_BACK) {
		        	final AlertDialog alt_bld = new AlertDialog.Builder(this).create();     
		    		alt_bld.setMessage("Do you want to Logout");
		    		alt_bld.setCancelable(false);
		    		alt_bld.setButton("Logout", new OnClickListener() { public void onClick(DialogInterface dialog, int which) { // TODO Auto-generated method stub dialog.cancel();
		    			alt_bld.cancel();
			        	Intent i = new Intent(NotificationActivity.this, MainActivity.class);
			         	startActivity(i);
			         	aa.finish();
		    		} });	    		
		    		alt_bld.setButton2("Cancel", new OnClickListener() { public void onClick(DialogInterface dialog, int which) { // TODO Auto-generated method stub dialog.cancel();
		    			alt_bld.cancel();
		    		} });
		    		alt_bld.show();
		        	return true;
		        }
		        return super.onKeyDown(keyCode, event);
		    }
}
