package com.example.e_votingsystem;

import java.util.ArrayList;
import java.util.List;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.BasicResponseHandler;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import com.example.e_votingsystem.JSONParser;
import com.example.e_votingsystem.GetIP;
import com.example.e_votingsystem.MainActivity;
import android.os.Bundle;
import android.app.Activity;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.util.Log;
import android.view.Menu;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends Activity implements OnClickListener {
	ProgressDialog dialog = null;
	MainActivity ua=null;
	Bundle b;
	private static final int NOTIFY_ME_ID=1336;
	HttpPost httppost;
	StringBuffer buffer;
	HttpResponse response;
	HttpClient httpclient;
	List<NameValuePair> nameValuePairs;
  	JSONParser jParser = new JSONParser();
  	private String jsonResult;
  	JSONParser jsonParser = new JSONParser();
	
	public static Button b1;
	public static Button b2;
	EditText voterid;
	public static String myipaddress="";
	public static String voter_id="";
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		ua=this;
		if(myipaddress.equals(""))
		{
		try {
	        Intent i = new Intent(getApplicationContext(), GetIP.class);
			startActivityForResult(i, 123);
		} catch(Exception ex) {
			Log.d("aa", ex.getMessage());
		}
		}
		voterid=(EditText)findViewById(R.id.voterid);
		
b1=(Button)findViewById(R.id.button1);
		
		b1.setOnClickListener(this);
		
		//using the saveInstanceState
		
		if(savedInstanceState==null)
		{
			
		}
		else
		{
			myipaddress=savedInstanceState.getString("IP");
			voter_id=savedInstanceState.getString("VoterId");
			
		}
		
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}
	
	

	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		// TODO Auto-generated method stub
		super.onActivityResult(requestCode, resultCode, data);
		 if (requestCode == 123) {

			 if(null!=data)
    	 		{	 	
    		 	// fetch the message String
    		 	myipaddress=data.getStringExtra("backIP");
    		 	Toast.makeText(MainActivity.this, myipaddress, Toast.LENGTH_SHORT).show();
    		 	// Set the message string in textView
    		
    	 		}
		     
		  }
	}
	
	@Override
	protected void onSaveInstanceState(Bundle outState) {
		// TODO Auto-generated method stub
		super.onSaveInstanceState(outState);
		
		outState.putString("IP", myipaddress);
		outState.putString("VoterId", voter_id);
	}

	@Override
	public void onClick(View arg0) {
		// TODO Auto-generated method stub
		checkVote();
		
		
	}


	private void checkVote() {
		// TODO Auto-generated method stub
		 try{
			 dialog = ProgressDialog.show(MainActivity.this, "",
						"Authenticating", true);
				new Thread(new Runnable() {
					public void run() {
						try {

							httpclient = new DefaultHttpClient();
							httppost = new HttpPost(
									"http://"+myipaddress+":80/evote/checkvote.php"); // make
																								// sure
																								// the
																								// url
																								// is
																								// correct.
							// add your data
							nameValuePairs = new ArrayList<NameValuePair>(2);
							// Always use the same variable name for posting i.e the android
							// side variable name and php side variable name should be similar,
							nameValuePairs.add(new BasicNameValuePair("name",voterid.getText().toString().trim())); 
							
							httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
							// Execute HTTP Post Request
							 Log.d("A", httppost.toString());
							ResponseHandler<String> responseHandler = new BasicResponseHandler();
							final String response = httpclient.execute(httppost,
									responseHandler);
							System.out.println("Response : " + response);
							
							/*Starting a thread and getting and displaying balance */
							runOnUiThread(new Runnable() {
								public void run() {
									if(response.equals("Not Voted")){
										Toast.makeText(MainActivity.this, response,Toast.LENGTH_LONG).show();
										dialog.dismiss();
										b = new Bundle();
										b.putString("IP", myipaddress);
										b.putString("VoterId", voterid.getText().toString().trim());
										Intent intent=new Intent(MainActivity.this, OtpGenerate.class);
										intent.putExtras(b);
										startActivity(intent);
									}
									else if(response.equals("Already Voted")){
									Toast.makeText(MainActivity.this, response,Toast.LENGTH_LONG).show();
									dialog.dismiss();
									viewnotification();
									
									}
									else if(response.equals("Invalid Voter")){
										dialog.dismiss();
										Toast.makeText(MainActivity.this, response,Toast.LENGTH_LONG).show();
										
									}
								}

								@SuppressWarnings("deprecation")
								private void viewnotification() {
									// TODO Auto-generated method stub
									final NotificationManager mgr=(NotificationManager)MainActivity.this.getSystemService(Context.NOTIFICATION_SERVICE);
						            Notification note=new Notification(R.drawable.ic_launcher, "E-Voting System", System.currentTimeMillis());
						            note.flags |= Notification.FLAG_AUTO_CANCEL;
						            Intent intent=new Intent(MainActivity.this, NotificationActivity.class);
						            b = new Bundle();
									b.putString("IP", myipaddress);
									b.putString("VoterId", voterid.getText().toString().trim());
									intent.putExtras(b);
						            // This pending intent will open after notification click
						            PendingIntent i=PendingIntent.getActivity(MainActivity.this, 0, intent, 0);
						            
						           
						            note.setLatestEventInfo(MainActivity.this, "Important Notification", "Tap here to view the notifications", i);
						             
						            
						            mgr.notify(NOTIFY_ME_ID, note);
								}
							});
							
							

						} catch (Exception e) {
							
							System.out.println("Exception : " + e.getMessage());
						}	
					}
				}).start();
		 }catch(Exception e)
		 {
			 
		 }
	}
	public boolean onKeyDown(int keyCode, KeyEvent event)  {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
        	ua.finish();        	
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }
}
