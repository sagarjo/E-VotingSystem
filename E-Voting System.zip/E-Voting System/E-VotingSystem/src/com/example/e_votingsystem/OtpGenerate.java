package com.example.e_votingsystem;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.BasicResponseHandler;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class OtpGenerate extends Activity implements OnClickListener{
	HttpPost httppost;
	StringBuffer buffer;
	HttpResponse response;
	HttpClient httpclient;
	List<NameValuePair> nameValuePairs;
	public static String myipaddress="";
	public static String voterid="";
	 JSONParser jsonParser = new JSONParser();
	 Bundle b;
	 ProgressDialog dialog = null;
	 String mobnumber;
	 EditText et1;
	 String id1="";
	 String id="";
	 String m="";
	 String response1="";
	 int position=0;
	 public static Button b1;
	 char st0;
	 String currentOTP = "";
	 String[][] multi = new String[][]{
			  { "M", "2", "U", "3", "O", "E"},
			  { "1", "A", "I", "Z", "J", "D"},
			  { "P", "8", "Q", "N", "B", "W"},
			  { "H", "S", "7", "C", "0", "L"},
			  { "Y", "6", "F", "X", "V", "4"},
			  { "T", "G", "5", "R", "9", "K"}
			};
	
	 ArrayList<String> str = new ArrayList<String>();
		
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_otp_generate);
		Bundle bundle = getIntent().getExtras();
		voterid=bundle.getString("VoterId");
		 myipaddress=bundle.getString("IP");
		 et1=(EditText)findViewById(R.id.editText1);
		 b1=(Button)findViewById(R.id.button1);
			
			b1.setOnClickListener(this);
			
			
	}
	
	
	@SuppressLint("UnlocalizedSms")
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// TODO Auto-generated method stub
		 position = item.getItemId();
		switch(item.getItemId())
		{
			
		case R.id.otpbymail:
			char[] alphNum = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789".toCharArray();

			Random rnd = new Random();

			StringBuilder sb = new StringBuilder();
			
			for (int i1 = 0; i1 < 6; i1++)
			    sb.append(alphNum[rnd.nextInt(alphNum.length)]);

			 id = sb.toString();
            currentOTP = id;
			Toast.makeText(OtpGenerate.this, id, Toast.LENGTH_LONG).show();
            Log.v("CHECK","OTP SMS " + id1);
			try{
				 dialog = ProgressDialog.show(OtpGenerate.this, "",
							"Sending OTP on mail id...", true);
					new Thread(new Runnable() {
						public void run() {
							try {

								httpclient = new DefaultHttpClient();
								httppost = new HttpPost(
										"http://"+myipaddress+":80/evote/smtp.php"); // make
																									// sure
																									// the
																									// url
																									// is
																									// correct.
								// add your data
								nameValuePairs = new ArrayList<NameValuePair>(2);
								// Always use the same variable name for posting i.e the android
								// side variable name and php side variable name should be similar,
								nameValuePairs.add(new BasicNameValuePair("names",voterid.toString().trim())); 
								nameValuePairs.add(new BasicNameValuePair("otp",id.trim())); 
								httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
								// Execute HTTP Post Request
								 Log.d("A", httppost.toString());
								ResponseHandler<String> responseHandler = new BasicResponseHandler();
								
								 response1 = httpclient.execute(httppost,responseHandler);
								System.out.println("Response : " + voterid.toString().trim());
								
								System.out.println("Response : " + response1);
								
								/*Starting a thread and getting and displaying balance */
								runOnUiThread(new Runnable() {
									public void run() {
										Toast.makeText(OtpGenerate.this,response1
												,Toast.LENGTH_LONG).show();
										
										dialog.dismiss();
										
									}
								});
								
								

							} catch (Exception e) {
								
								System.out.println("Exception : " + e.getMessage());
							}	
						}
					}).start();
			 }catch(Exception e)
			 {
				 
			 }
			
			break;
			
		case R.id.otpbysms:
			char[] alphNum1 = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789".toCharArray();

			Random rnd1 = new Random();

			StringBuilder sb1 = new StringBuilder();
			
			for (int i1 = 0; i1 < 6; i1++)
			    sb1.append(alphNum1[rnd1.nextInt(alphNum1.length)]);

		 id1 = sb1.toString();
            currentOTP = id1;
			Toast.makeText(OtpGenerate.this, id1, Toast.LENGTH_LONG).show();
			Log.v("CHECK","OTP SMS " + id1);
		 	
			System.out.println(id1);
			try{
				 dialog = ProgressDialog.show(OtpGenerate.this, "",
							"Checking Mobile Number...", true);
					new Thread(new Runnable() {
						public void run() {
							getmob();		
						}
					}).start();
			 }catch(Exception e)
			 {
				 
			 }
			
			
		break;
		
		default:
			
		break;
		
		}
		return super.onOptionsItemSelected(item);
	}
	


	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.otp_generate, menu);
		return true;
	}
	
	
	protected void getmob() {

		try {

			httpclient = new DefaultHttpClient();
			httppost = new HttpPost(
					"http://"+myipaddress+":80/evote/mobnumber.php"); // make
																				// sure
																				// the
																				// url
																				// is
																				// correct.
			// add your data
			nameValuePairs = new ArrayList<NameValuePair>(2);
			// Always use the same variable name for posting i.e the android
			// side variable name and php side variable name should be similar,
			nameValuePairs.add(new BasicNameValuePair("names",voterid.toString().trim())); 
			System.out.println("Response : " + voterid.toString().trim());
			httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
			 Log.d("A", httppost.toString());
			ResponseHandler<String> responseHandler = new BasicResponseHandler();
			final String response = httpclient.execute(httppost,
					responseHandler);
			System.out.println("Response : " + response);
			
			/*Starting a thread and getting and displaying balance */
			runOnUiThread(new Runnable() {
				public void run() {
					Toast.makeText(OtpGenerate.this,"Mobilenumber is " + response,Toast.LENGTH_LONG).show();
					  /** Getting an instance of SmsManager to sent sms message from the application*/
			             SmsManager smsManager = SmsManager.getDefault();

			             /** Sending the Sms message to the intended party */
			           smsManager.sendTextMessage(response, null, "Welcome To E-Voting System. Use this OTP: "+id1+ " for Login.", null, null);
				
					mobnumber=response;
					dialog.dismiss();
					
				}
			});
			
			

		} catch (Exception e) {
			
			System.out.println("Exception : " + e.getMessage());
		}

	}


	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		try{
			 dialog = ProgressDialog.show(OtpGenerate.this, "",
						"Authenticating...", true);
            authenticate();
        }catch(Exception e)
		 {
             dialog.cancel();
		 }
	}

	protected void authenticate() {
        Log.v("CHECK","OTP " + id + ": "+id1);
		// TODO Auto-generated method stub
		try {
			if(position==1){
			    Log.v("CHECK","AUTHENTICATING id1 " + id1);
//		st0=id1.charAt(0);
//		char st1=id1.charAt(1);
//		char st2=id1.charAt(2);
//		char st3=id1.charAt(3);
//		char st4=id1.charAt(4);
//		char st5=id1.charAt(5);
//		System.out.println(st0+","+st1+","+st2+","+st3+","+st4+","+st5);
//
//				int q0=wordSearch(String.valueOf(st0));
//					System.out.println("q0 "+q0);
//					int q1=wordSearch1(String.valueOf(st1));
//					System.out.println("q1 "+q1);
//					int q2=wordSearch(String.valueOf(st2));
//					System.out.println("q2 "+q2);
//					int q3=wordSearch1(String.valueOf(st3));
//					System.out.println("q3 "+q3);
//					int q4=wordSearch(String.valueOf(st4));
//					System.out.println("q4 "+q4);
//					int q5=wordSearch1(String.valueOf(st5));
//					System.out.println("q5 "+q5);
//
//					 m=multi[q0][q1]+multi[q2][q3]+multi[q4][q5];
//					System.out.println(m);


                if(et1.getText().toString().trim().toUpperCase().equals(currentOTP.toUpperCase())){
                    Toast.makeText(OtpGenerate.this,"Login Sucess ",Toast.LENGTH_LONG).show();
                    Intent intent = new Intent(this,CandidateActivity.class);
                    b = new Bundle();
                    b.putString("IP", myipaddress);
                    b.putString("VoterId", voterid);
                    intent.putExtras(b);
                    startActivity(intent);
                }
                else{
                    Toast.makeText(OtpGenerate.this,"Login Failed",Toast.LENGTH_LONG).show();

                }
                dialog.dismiss();
		
			}
			else{
                Log.v("CHECK","AUTHENTICATING id " + id + " "+ currentOTP);
                Log.v("CHECK","AUTHENTICATING text" + et1.getText() );
//				st0=id.charAt(0);
//				char st1=id.charAt(1);
//				char st2=id.charAt(2);
//				char st3=id.charAt(3);
//				char st4=id.charAt(4);
//				char st5=id.charAt(5);
//				System.out.println(st0+","+st1+","+st2+","+st3+","+st4+","+st5);
//
//						int q0=wordSearch(String.valueOf(st0));
//							System.out.println("q0 "+q0);
//							int q1=wordSearch1(String.valueOf(st1));
//							System.out.println("q1 "+q1);
//							int q2=wordSearch(String.valueOf(st2));
//							System.out.println("q2 "+q2);
//							int q3=wordSearch1(String.valueOf(st3));
//							System.out.println("q3 "+q3);
//							int q4=wordSearch(String.valueOf(st4));
//							System.out.println("q4 "+q4);
//							int q5=wordSearch1(String.valueOf(st5));
//							System.out.println("q5 "+q5);
//
//							 m=multi[q0][q1]+multi[q2][q3]+multi[q4][q5];
//							System.out.println(m);



                if(et1.getText().toString().trim().toUpperCase().equals(currentOTP.toUpperCase())){
                    Toast.makeText(OtpGenerate.this,"Login Sucess ",Toast.LENGTH_LONG).show();
                    Intent intent = new Intent(this,CandidateActivity.class);
                    b = new Bundle();
                    b.putString("IP", myipaddress);
                    b.putString("VoterId", voterid);
                    intent.putExtras(b);
                    startActivity(intent);
                }
                else{
                    Toast.makeText(OtpGenerate.this,"Login Failed",Toast.LENGTH_LONG).show();

                }
                dialog.dismiss();
				
			}
					} catch (Exception e) {
						
						System.out.println("Exception : " + e.getMessage());
					}

					}
	
			
			public int wordSearch(String s) {
				int row=0;
				int col=0;
		            // Check each letter in grid
		            for ( row = 0; row <6; row++)
		            {
		                    for ( col = 0; col < 6; col++)
		                    {
		                           if(multi[row][col].equals(s)){
		                        	   return row;
		                           }
		                    }
		    }
					return row;
					 
		
	}
			public int wordSearch1(String s) {
				int row=0;
				int col=0;
		            // Check each letter in grid
		            for ( row = 0; row <6; row++)
		            {
		                    for ( col = 0; col < 6; col++)
		                    {
		                           if(multi[row][col].equals(s)){
		                        	   return col;
		                           }
		                    }
		    }
					return col;
					 
		
	}
	}