package com.example.e_votingsystem;



import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class GetIP extends Activity{

	EditText etGetIP;
	Button btnSaveIP;
	String result;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		
		setContentView(R.layout.getip);
		
		etGetIP = (EditText) findViewById(R.id.edtIP);
		btnSaveIP = (Button) findViewById(R.id.btnIP);

		btnSaveIP.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				result = etGetIP.getText().toString().trim();
				Intent intentMessage = new Intent();

				// put the message in Intent
				intentMessage.putExtra("backIP", result);
				// Set The Result in Intent
				setResult(123, intentMessage);
				finish();

			}
		});

		
	}
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
	    if(keyCode==KeyEvent.KEYCODE_BACK)
	        Toast.makeText(getApplicationContext(), "back press",      
	     Toast.LENGTH_LONG).show();

	    return false;
	       // Disable back button..............
	} 
	
	
	
}
