package com.example.e_votingsystem;

public class Notify {
	private String candidatename;
	private String votes;
	
	
	public Notify(String candidatename, String votes) {
		super();
		this.candidatename = candidatename;
		this.votes = votes;
	}
	public String getCandidatename() {
		return candidatename;
	}
	public void setCandidatename(String candidatename) {
		this.candidatename = candidatename;
	}
	public String getVotes() {
		return votes;
	}
	public void setVotes(String votes) {
		this.votes = votes;
	}
	
	

}
