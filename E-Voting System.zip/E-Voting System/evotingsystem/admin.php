<?php
if(isset($_POST['submit'])){
	
$name=$_POST['username']; 
$pass=$_POST['password'];

if($name=='admin' && $pass=='admin'){
	header("Location: home.html");
}

else{
	header("Location: index.html");
}
}
?>