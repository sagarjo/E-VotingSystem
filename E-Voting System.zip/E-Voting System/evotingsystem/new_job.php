<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
<!-- <link href="./css/bootstrap.min.css" rel="stylesheet"> -->
<link href="./css/datepicker.css" rel="stylesheet">
</head>
<body>
	<div class="container">
		<div class="modal fade" id="mymodal">
			<div class="modal-dialog">
				<div class="modal-content">
					<div class="modal-header">
						<button class="close" type="button" data-dismiss="modal" aria-hidden="true">&times;</button>
						<h4 class="modal-title">Information</h4>
					</div>
					<div class="modal-body">
						<p id="bodyText"></p>
					</div>
					<div class="modal-footer">
						<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
					</div>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-lg-6">
				<div id="alertdiv">
					
				</div>
				<form action="" method="POST" role="form">
					<div class="form-group">
						<label class="col-xs-2 control-label" for="jobtitle">Job
							title:</label>
						<div class="col-xs-10">
							<input type="text" style="margin-bottom: 10px" id="title" name="title"
								class="form-control" placeholder="Enter the job title" required="required"/>
						</div>
					</div>
					<div class="form-group">
						<label class="col-xs-2 control-label" for="designation">Designation:</label>
						<div class="col-xs-10">
							<input type="text" id="designation" style="margin-bottom: 10px" name="designation"
								class="form-control" placeholder="Enter designation" required="required"/>
						</div>
					</div>
					<div class="form-group">
						<label class="col-xs-2 control-label" for="experience">Experience:</label>
						<div class="col-xs-10">
							<input type="number" id="title" style="margin-bottom: 10px" name="experience"
								class="form-control" min="0" max="15"
								placeholder="Enter number of years experience" required="required"/>
						</div>
					</div>
					<div class="form-group">
						<label class="col-xs-2 control-label" for="skills">Skills:</label>
						<div class="col-xs-10">
							<input type="text" id="title" style="margin-bottom: 10px" name="skills"
								class="form-control" placeholder="Java, C#, Ruby etc." required="required"/>
						</div>
					</div>
					<div class="form-group">
						<label class="col-xs-2 control-label" for="description">Description:</label>
						<div class="col-xs-10">
							<textarea rows="5" cols="10" id="title" name="description"
								style="margin-bottom: 10px" class="form-control"
								placeholder="Enter the job description" required="required"></textarea>
						</div>
					</div>
					<div class="form-group">
						<label class="col-xs-2 control-label" for="skills">Apply
							between:</label> <label class="col-xs-1 control-label" for="skills">From</label>
						<div class="col-xs-4">
							<input type="text" id="startdt" name="startdt" data-provide="datepicker"
								style="margin-bottom: 10px" class="datepicker form-control" required="required"/>
						</div>
						<label class="col-xs-1 control-label" for="skills">till</label>
						<div class="col-xs-4">
							<input type="text" id="enddt" name="enddt" data-provide="datepicker"
								style="margin-bottom: 10px" class="datepicker form-control" required="required"/>
						</div>
					</div>
					<div class="form-group">
						<div class="pull-right">
							<div class="col-xs-12">
								<input class="btn btn-default" type="reset" value="Reset"/>
								&nbsp;
								<input class="btn btn-primary" type="submit" value="Submit"/>
							</div>
						</div>
					</div>
				</form>
			</div>
		</div>
	</div>
	<!-- <script
		src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
	<script src="./js/bootstrap.min.js"></script> -->
	<script src="./js/bootstrap-datepicker.js"></script>
	<script>
		$(document).ready(function() {
			$('.datepicker').datepicker();
		});
		function parseDate(input){
			var parts = input.split('/');
			console.log("Month:"+parts[0]);
			console.log("Day:"+parts[1]);
			console.log("Year:"+parts[2]);
			return new Date(parts[2],parts[0]-1,parts[1]);
		}
		function validate(){
			var startdt = $('#startdt').val();
			var enddt = $('#enddt').val();
			//var startDateString = Date.parseDate(startdt,"")//startdt.match(/^(\d{2})\/(\d{2})\/(\d{4})$/);
			//var endDateString = enddt.match(/^(\d{2})\/(\d{2})\/(\d{4})$/);
			var startDate = parseDate(startdt);
			var endDate = parseDate(enddt);
			if(startDate >= endDate){
				$('#bodyText').html("End date cannot be behind start date or same as start date.");
				$('#mymodal').modal('show');
				return false;
			}
				
			
			return true;
		}
		function alertTimeout(wait){
			setTimeout(function(){
				$('#alertdiv').children('.alert:first-child').remove();
			},wait);
		}
		$(document).ready(function(){
			$('form').submit(function(e){
				e.preventDefault();
				if(validate()){
					$.ajax({
						type: 'POST',
						url : '/B-OLI/newjob',
						data : $('form').serialize(),
						success : function(data){
							var alert = "<div class='alert alert-success alert-dismissable' role='alert'>"
								+ "<button type='button' class='close' data-dismiss='alert' aria-label='Close'"
								+ "<span aria-hidden='true'>&times;</span></button>"
								+ "<strong>"+data+"</strong></div>";
							$('#alertdiv').append(alert);
							alertTimeout(5000);
						},
						error : function(xhr, status, error){
							console.log(" status:"+status+" error:"+error+" status Text:"+xhr.statusText);
							var responseText = xhr.responseText;
							var text = $(responseText).text();
							var message = text.substring(text.lastIndexOf('message')+"message".length,text.lastIndexOf('description')).trim();
							$('#bodyText').html(message);
							$('#mymodal').modal('show');
						}
					});
				}
			});
		});
	</script>
</body>
</html>