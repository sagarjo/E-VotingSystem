<?php
$hostname_localhost ="localhost";
$database_localhost ="votingsystem";
$username_localhost ="root";
$password_localhost ="";
$localhost = mysql_connect($hostname_localhost,$username_localhost,$password_localhost)
or
trigger_error(mysql_error(),E_USER_ERROR);

mysql_select_db($database_localhost, $localhost);

$votername = $_POST['name'];
$voterid = $_POST['voterid'];
$adharcard = $_POST['adharcard'];
$age = $_POST['age'];
$mob = $_POST['mob'];
$mail = $_POST['mail'];
$ward=$_POST['ward'];

 $result = mysql_query("INSERT INTO `voterlist`(`full_name`, `voterid`, `aadharcard_no`, `age`, `mob`, `email_id`,ward) VALUES('$votername',$voterid,$adharcard,$age,$mob,'$mail', '$ward')");
    // check if row inserted or not
    if ($result) {
    
header("Location: examples.html"); 
 }
 else  {
	header("Location: home.html"); 
}

?>