<?php
$hostname_localhost ="localhost";
$database_localhost ="votingsystem";
$username_localhost ="root";
$password_localhost ="";
$localhost = mysql_connect($hostname_localhost,$username_localhost,$password_localhost)
or
trigger_error(mysql_error(),E_USER_ERROR);

mysql_select_db($database_localhost, $localhost);
$query_search = "SELECT * FROM `candidatelist`";
$query_exec = mysql_query($query_search) or die(mysql_error());
$rows = mysql_num_rows($query_exec);
$retval = mysql_query($query_search,$localhost );
//echo $rows;
 if($rows == 0) { 
 echo "Not Found"; 
 }
 else  {
while($row = mysql_fetch_array($retval, MYSQL_ASSOC))
{
	

        echo $row['fullname'];
		echo $row['email'];
          
        
        	
}
}

?>