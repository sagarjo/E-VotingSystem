<!DOCTYPE HTML>
<html>

<head>
  <title>E-Voting System</title>
  <meta name="description" content="website description" />
  <meta name="keywords" content="website keywords, website keywords" />
  <meta http-equiv="content-type" content="text/html; charset=windows-1252" />
  <link rel="stylesheet" type="text/css" href="style/style.css" />
  <link rel="stylesheet" type="text/css" media="all" href="style/style_2.css">
  <link rel="stylesheet" type="text/css" media="all" href="style/responsive.css">
  
  <script>
function validateForm() {
	var z = document.forms["form3"]["age"].value;
    if (z.length != 2) {
        alert("Please Enter 2 digit age");
        return false;
    }
	var a = document.forms["form3"]["mob"].value;
    if (a.length != 10) {
        alert("Please Enter 10 digit Mobile Number");
        return false;
    }
}
</script>
</head>

<body>
  <div id="main">
    <div id="header">
      <div id="logo">
        <div id="logo_text">
          <!-- class="logo_colour", allows you to change the colour of the text -->
         <h1><a href="home.html">E-<span class="logo_colour">voting System</span></a></h1>
 </div>
      </div>
      <div id="menubar">
        <ul id="menu">
          <!-- put class="selected" in the li tag for the selected page - to highlight which page you're on -->
         <li><a href="home.html">Home</a></li>
          <li><a href="examples.html">Register Voter</a></li>
          <li><a href="page.html">Register Candidate</a></li>
		   <li class="selected"><a href="candidate.php">Candidate Details</a></li>
          <li ><a href="another_page.php">Voting History</a></li>
          <li><a href="index.html">Logout</a></li>
         </ul>
      </div>
    </div>
    <div id="content_header"></div>
    <div id="site_content">
      <div id="sidebar_container">
        
        
      </div>
	   <div id="content">
	   <section id="container" >
        <!-- insert the page content here -->
		<form name="form1" action="" method="POST">
        <h1>Delete Candidate</h1>
		<section id="aside" class="clearfix">
				<section id="recipientcase">
				<h3>Candidate:</h3>
					<select id="recipient" name="recipient" tabindex="1" class="selmenu">
					<?php
$hostname_localhost ="localhost";
$database_localhost ="votingsystem";
$username_localhost ="root";
$password_localhost ="";
$localhost = mysql_connect($hostname_localhost,$username_localhost,$password_localhost)
or
trigger_error(mysql_error(),E_USER_ERROR);

mysql_select_db($database_localhost, $localhost);
$query_search = "SELECT fullname FROM `candidatelist`";
$query_exec = mysql_query($query_search) or die(mysql_error());
$rows = mysql_num_rows($query_exec);
$retval = mysql_query($query_search,$localhost );
//echo $rows;
 if($rows == 0) { 

 }
 else  {
while($row = mysql_fetch_array($retval, MYSQL_ASSOC))
{
?>
  						<option value="<?php echo $row['fullname']; ?>"><?php echo $row['fullname']; ?></option>
<?php			  }  
			  }
?>
					</select>
				</section>
				<section id="buttons">
			<input type="submit" name="submit1" id="submitbtn" class="submitbtn" tabindex="2" value="Delete">
			<br style="clear:both;">
		</section>
				</form>
<?php
if(isset($_POST['submit1'])){
$name=$_POST['recipient'];
$query_search = "DELETE FROM `candidatelist` where fullname='".$name. "'";
$query_exec = mysql_query($query_search) or die(mysql_error());
}
?>
		 <form name="form2" action="" method="POST">
       
		 <h1>Update Candidate Details</h1>
		<section id="aside" class="clearfix">
				<section id="recipientcase">
				<h3>Candidate:</h3>
					<select id="recipient" name="recipient1" tabindex="3" class="selmenu">
<?php				
$query_search = "SELECT * FROM `candidatelist`";
$query_exec = mysql_query($query_search) or die(mysql_error());
$rows = mysql_num_rows($query_exec);
$retval = mysql_query($query_search,$localhost );
//echo $rows;
 if($rows == 0) { 

 }
 else  {
while($row = mysql_fetch_array($retval, MYSQL_ASSOC))
{
?>
	<option value="<?php echo $row['fullname']; ?>"><?php echo $row['fullname']; ?></option>
<?php			  }  
			  }
?>
					</select>
				</section>
				<section id="buttons">
			<input type="submit" name="submit2" id="submitbtn" class="submitbtn" tabindex="4" value="Update">
			<br style="clear:both;">
		</section>
				</form>
				
	
<?php
if(isset($_POST['submit2'])){
$name=$_POST['recipient1'];
$query_search = "SELECT * FROM `candidatelist` where fullname='".$name."'";
$query_exec = mysql_query($query_search) or die(mysql_error());
$rows = mysql_num_rows($query_exec);
$retval = mysql_query($query_search,$localhost );
//echo $rows;
 if($rows == 0) { 
 }
 else  {
if($row = mysql_fetch_array($retval, MYSQL_ASSOC))
{
?>
<form name="form3" action="" method="POST" onsubmit="return validateForm()">
<div id="wrapping" class="clearfix">
			<section id="aligned">
		
	<br><h3>Candidate Name:</h3><input type="text" id="name" name="name" value="<?php echo $row['fullname']; ?>"  placeholder="Full name" autocomplete="off" tabindex="1" class="txtinput" required="required">
	<br><h3>Age:</h3><input type="number" name="age" value="<?php echo $row['age']; ?>" id="email" placeholder="Age" autocomplete="off" tabindex="2" class="txtinput" required="required">
	<br><h3>Education:</h3><input type="text" name="education" value="<?php echo $row['education']; ?>" id="website" placeholder="Education" autocomplete="off" tabindex="3" class="txtinput" required="required">
	<br><h3>Mobile Number:</h3><input type="number" name="mob" value="<?php echo $row['mobile_number']; ?>" id="telephone" placeholder="Mobile Number" tabindex="4" class="txtinput" required="required">
	<br><h3>Email Id:</h3><input type="email" name="mail" value="<?php echo $row['email']; ?>" id="telephone" placeholder="Email Id" tabindex="5" class="txtinput" required="required">
	<br><h3>Ward Name:</h3><input type="text" name="ward" value="<?php echo $row['ward']; ?>" id="name" placeholder="Ward Name" tabindex="6" class="txtinput" required="required">
		
		<h3>Marital Status:</h3>
		<?php
		if($row['marital_status']=="Unmarried"){
			?>
			<span class="radiobadge"><input type="radio" name="status" value="Married" >Married</span>
			<span class="radiobadge"><input type="radio" name="status" value="Unmarried" checked>Unmarried</span>
	<?php
		}else{
			?>
			<span class="radiobadge"><input type="radio" name="status" value="Married" checked>Married</span>
			<span class="radiobadge"><input type="radio" name="status" value="Unmarried" >Unmarried</span>
	<?php	} ?>
			<h3>All Documents Submitted?</h3>
			<?php
		if($row['all_doc_submit']=="Yes"){
			?>
			<span class="radiobadge">
					<input type="radio" name="doc" value="Yes" checked>Yes</span>
			<span class="radiobadge">
					<input type="radio" name="doc" value="No">No</span>
					<?php
					}else{
			?>
			<span class="radiobadge">
					<input type="radio" name="doc" value="Yes" >Yes</span>
			<span class="radiobadge">
					<input type="radio" name="doc" value="No" checked>No</span>
					<?php	} ?>
			</section></div>
  					</select>
				</section>
		<section id="buttons">
			<input type="submit" name="submit3" id="submitbtn" class="submitbtn" tabindex="7" value="Update">
			<br style="clear:both;">
		</section>
				</form>
		
		<?php   }
 }
}

if(isset($_POST['submit3'])){
$name=$_POST['name'];
$age = $_POST['age'];
$education = $_POST['education'];
$mob = $_POST['mob'];
$mail = $_POST['mail'];
$status=$_POST['status'];
$doc=$_POST['doc'];
$ward=$_POST['ward'];


$query_search = "UPDATE `candidatelist` SET `fullname`='".$name."',`age`=".$age.",`education`='".$education."',`marital_status`='".$status."',`all_doc_submit`='".$doc."',`mobile_number`=$mob,`email`='".$mail."', ward='".$ward."' WHERE fullname='".$name."'";
$query_exec = mysql_query($query_search) or die(mysql_error());
}
?>

			
				
		</div></div>
		</div>
    </div>
    <div id="content_footer"></div>
    <div id="footer">
      <p><a href="home.html">Home</a> | <a href="examples.html">Register Voter</a> | <a href="page.html">Register Candidate</a> | <a href="another_page.php">Voting History</a></p>
      <p>Copyright &copy; E-Voting System  </div>
  </div>
  </div>
</body>
</html>