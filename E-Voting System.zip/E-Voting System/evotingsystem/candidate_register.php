<?php
$hostname_localhost ="localhost";
$database_localhost ="votingsystem";
$username_localhost ="root";
$password_localhost ="";
$localhost = mysql_connect($hostname_localhost,$username_localhost,$password_localhost)
or
trigger_error(mysql_error(),E_USER_ERROR);

mysql_select_db($database_localhost, $localhost);

$votername = $_POST['name'];
$education = $_POST['education'];
$status=$_POST['status'];
$doc=$_POST['doc'];
$age = $_POST['age'];
$mob = $_POST['mob'];
$mail = $_POST['mail'];
$ward=$_POST['ward'];

 $result = mysql_query("INSERT INTO `candidatelist`( `fullname`, `age`, `education`, `marital_status`, `all_doc_submit`, `mobile_number`,`email`,`votes`,ward) VALUES('$votername',$age,'$education','$status','$doc',$mob,'$mail',0,'$ward')");
    // check if row inserted or not
    if ($result) {
    
header("Location: page.html"); 
 }
 else  {
	header("Location: home.html"); 
}

?>