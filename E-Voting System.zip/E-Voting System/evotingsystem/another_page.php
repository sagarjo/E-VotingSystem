<!DOCTYPE HTML>
<html>

<head>
  <title>E voting System</title>
  <meta name="description" content="website description" />
  <meta name="keywords" content="website keywords, website keywords" />
  <meta http-equiv="content-type" content="text/html; charset=windows-1252" />
  <link rel="stylesheet" type="text/css" href="style/style.css" />
</head>

<body>
  <div id="main">
    <div id="header">
      <div id="logo">
        <div id="logo_text">
          <!-- class="logo_colour", allows you to change the colour of the text -->
         <h1><a href="home.html">E-<span class="logo_colour">voting System</span></a></h1>
 </div>
      </div>
      <div id="menubar">
        <ul id="menu">
          <!-- put class="selected" in the li tag for the selected page - to highlight which page you're on -->
         <li><a href="home.html">Home</a></li>
          <li><a href="examples.html">Register Voter</a></li>
          <li><a href="page.html">Register Candidate</a></li>
		   <li><a href="candidate.php">Candidate Details</a></li>
          <li class="selected"><a href="another_page.php">Voting History</a></li>
          <li><a href="index.html">Logout</a></li>
         </ul>
      </div>
    </div>
    <div id="content_header"></div>
    <div id="site_content">
      <div id="sidebar_container">
        
        
      </div>
	   <div id="content">
        <!-- insert the page content here -->
        <h1>Candidates Details</h1>

        <table style="width:100%; border-spacing:0;">
          <tr><th>Candidate's Name</th><th>Email_Id</th><th>Age</th><th>Education</th><th>Mobile Number</th><th>Marital Status</th><th>Ward</th><th>Doc Submitted?</th></tr>
       
<?php
$hostname_localhost ="localhost";
$database_localhost ="votingsystem";
$username_localhost ="root";
$password_localhost ="";
$localhost = mysql_connect($hostname_localhost,$username_localhost,$password_localhost)
or
trigger_error(mysql_error(),E_USER_ERROR);

mysql_select_db($database_localhost, $localhost);
$query_search = "SELECT * FROM `candidatelist` ORDER BY ward";
$query_exec = mysql_query($query_search) or die(mysql_error());
$rows = mysql_num_rows($query_exec);
$retval = mysql_query($query_search,$localhost );
//echo $rows;
 if($rows == 0) { 
 echo "Not Found"; 
 }
 else  {
while($row = mysql_fetch_array($retval, MYSQL_ASSOC))
{
?>
			<tr><td><?php echo $row['fullname']; ?></td><td><?php echo $row['email'];?></td>
			<td><?php echo $row['age']; ?></td><td><?php echo $row['education']; ?></td>
			<td><?php echo $row['mobile_number']; ?></td><td><?php echo $row['marital_status']; ?></td>
			<td><?php echo $row['ward']; ?></td><td><?php echo $row['all_doc_submit']; ?></td> </tr>
<?php			  }  
			  }
?>
		 </table>
		 
		 <h1>Candidates Voting History</h1>
		<table style="width:100%; border-spacing:0;">
          <tr><th>Candidate's Name</th><th>Ward</th><th>No of Votes</th></tr>
<?php
$query_search = "SELECT fullname,ward, votes FROM `candidatelist` ORDER BY ward,votes DESC";
$query_exec = mysql_query($query_search) or die(mysql_error());
$rows = mysql_num_rows($query_exec);
$retval = mysql_query($query_search,$localhost );
//echo $rows;
 if($rows == 0) { 
 echo "Not Found"; 
 }
 else  {
while($row = mysql_fetch_array($retval, MYSQL_ASSOC))
{
?>
			<tr><td><?php echo $row['fullname']; ?></td><td><?php echo $row['ward']; ?></td><td><?php echo $row['votes'];?></td></tr>
<?php			  }  
			  }
?>	
		 
		 </table>
		</div>
    </div>
    <div id="content_footer"></div>
    <div id="footer">
      <p><a href="home.html">Home</a> | <a href="examples.html">Register Voter</a> | <a href="page.html">Register Candidate</a>|<a href="candidate.php">Candidate Details</a> | <a href="another_page.php">Voting History</a></p>
      <p>Copyright &copy; E-Voting System  </div>
  </div>
  </div>
</body>
</html>
