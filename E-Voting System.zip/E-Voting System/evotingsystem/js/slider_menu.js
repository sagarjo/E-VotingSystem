/**
 * 
 */
$("#menu-toggle").click(function(e) {
	e.preventDefault();
	$("#wrapper").toggleClass("toggled");
});
$("#menu-toggle-2").click(function(e) {
	e.preventDefault();
	$(this).children().toggleClass('fa-chevron-left fa-chevron-right');
	$("#wrapper").toggleClass("toggled-2");
	$('#menu ul').hide();
});

function initMenu() {
	$('#menu ul').hide();
	$('#menu ul').children('.current').parent().show();
	$('#menu li a').click(function(){
		
		var element = $(this).next();
		if(element.is('ul'))
		{
			$(this).parent().siblings().removeClass('active');
			element.slideToggle('normal');
			$(this).parent().addClass('active');
		}
		else{
			if($(this).parent().parent().hasClass('nav-stacked'))
			{
				$(this).parent().siblings().removeClass('active');
				$(this).parent().addClass('active');
			}
		}
	});
}
$(document).ready(function() {
	initMenu();
});