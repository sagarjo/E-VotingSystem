-- phpMyAdmin SQL Dump
-- version 3.5.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Nov 25, 2015 at 10:47 AM
-- Server version: 5.5.24-log
-- PHP Version: 5.3.13

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `votingsystem`
--

-- --------------------------------------------------------

--
-- Table structure for table `candidatelist`
--

CREATE TABLE IF NOT EXISTS `candidatelist` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fullname` varchar(50) NOT NULL,
  `age` int(2) NOT NULL,
  `education` varchar(50) NOT NULL,
  `marital_status` varchar(10) NOT NULL,
  `all_doc_submit` varchar(5) NOT NULL,
  `mobile_number` bigint(10) NOT NULL,
  `email` varchar(40) NOT NULL,
  `ward` varchar(40) NOT NULL,
  `votes` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `candidatelist`
--

INSERT INTO `candidatelist` (`id`, `fullname`, `age`, `education`, `marital_status`, `all_doc_submit`, `mobile_number`, `email`, `ward`, `votes`) VALUES
(2, 'Rahul Mehta', 24, 'BE', 'No', 'Yes', 7687987890, 'rahul@gmail.com', 'Thane', 1),
(3, 'Sagar Patil', 40, 'B.Com', 'Married', 'Yes', 7690875645, 'sagarpatil@gmail.com', 'Mulund', 0),
(4, 'Manish Shah', 45, 'B.E.', 'Married', 'Yes', 7654678754, 'manish@gmail.com', 'Mulund', 0),
(5, 'Rohit Mane', 30, 'M.Com', 'Married', 'Yes', 9954679810, 'rohitmane21@gmail.com', 'Thane', 0);

-- --------------------------------------------------------

--
-- Table structure for table `candy`
--

CREATE TABLE IF NOT EXISTS `candy` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fullname` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `candy`
--

INSERT INTO `candy` (`id`, `fullname`) VALUES
(1, 'Mahesh Patil'),
(2, 'Rahul Mehta');

-- --------------------------------------------------------

--
-- Table structure for table `voterlist`
--

CREATE TABLE IF NOT EXISTS `voterlist` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `full_name` varchar(50) NOT NULL,
  `voterid` varchar(20) NOT NULL,
  `aadharcard_no` bigint(20) NOT NULL,
  `age` int(2) NOT NULL,
  `mob` bigint(10) NOT NULL,
  `email_id` varchar(40) NOT NULL,
  `ward` varchar(40) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `voterlist`
--

INSERT INTO `voterlist` (`id`, `full_name`, `voterid`, `aadharcard_no`, `age`, `mob`, `email_id`, `ward`) VALUES
(1, 'Mirinal Patil', '12345', 1234556788, 20, 7323232323, 'minal@jeettechnosolutions.com', 'Thane'),
(2, 'Neha Patil', '23456', 43434343, 40, 7345765430, 'nehap@gmail.com', 'Mulund'),
(3, 'Smruti Arekar', '444564', 4335670877, 20, 8087655675, 'smrutiarekar@gmail.com', 'Thane'),
(4, 'Rahul Kanekar', '293445', 76454433, 25, 8087344567, 'rahulkanekar@gmail.com', 'Mulund');

-- --------------------------------------------------------

--
-- Table structure for table `votes`
--

CREATE TABLE IF NOT EXISTS `votes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `voterid` bigint(20) NOT NULL,
  `votetime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `voterid` (`voterid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `votes`
--

INSERT INTO `votes` (`id`, `voterid`, `votetime`) VALUES
(1, 12345, '2015-11-25 09:45:01');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
